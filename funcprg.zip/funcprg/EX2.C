//ex2
#include<stdio.h>
#include<conio.h>

void table(int n)
{
	int i;
	for(i=1;i<=10;i++)
	{
		printf("\n%d * %d = %d",n,i,n*i);
	}
}
void main()
{
	int no;
	clrscr();
	printf("\nEntre any number you want: ");
	scanf("%d",&no);
	table(no);
	getch();
}