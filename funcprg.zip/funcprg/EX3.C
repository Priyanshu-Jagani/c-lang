#include<stdio.h>
#include<conio.h>


void oddeven(int n)
{
	if(n%2==0)
	{
		printf(" %d Number is even",n);
	}
	else
	{
		printf(" %d Number is odd",n);
	}
}
void main()
{
	int n;
	clrscr();

	printf("\nEnter any number: ");
	scanf("%d",&n);
	oddeven(n);

	getch();
}