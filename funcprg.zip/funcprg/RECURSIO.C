//recursion using factorial
#include<stdio.h>
#include<conio.h>

int fact(int n)
{
	int f;
	if(n==0)
	{
		return 1;
	}
	else
	{
		f=n*fact(n-1);
	}
	return f;
}
void main()
{
	int no, ans;
	clrscr();
	printf("\nEnter any number: ");
	scanf("%d",&no);
	ans=fact(no);
	printf("\nfactorial of %d is %d ",no,ans);
	getch();
}