//ex 1
#include<stdio.h>
#include<conio.h>

void sum(float a, float b)
{
	float avg,add;
	add=a+b;
	printf("Sum of n1 and n2 is %f",add);
	avg=add/2;
	printf("\nAverage of n1 and n2 is %f",avg);
}
void main()
{
	float n1,n2;
	clrscr();
	printf("\nEnter first number: ");
	scanf("%f",&n1);
	printf("\nEnter second number: ");
	scanf("%f",&n2);
	sum(n1,n2);
	getch();
}