//ex5
#include<stdio.h>
#include<conio.h>
int max(int x,int y);
void main()
{
	int a, b, u;
	clrscr();
	printf("\nEnter any number: ");
	scanf("%d",&a);
	printf("\nEnter any number: ");
	scanf("%d",&b);
	u=max(a,b);
	printf("\nmax is %d ",u);
	getch();
}

int max(int x, int y)
{
	if(x>y)
	{
		return x;
	}
	else
	{
		return y;
	}
}