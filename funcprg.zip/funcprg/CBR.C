/*#include<stdio.h>
#include<conio.h>

void swap(int *x, int *y)
{
	int temp;
	temp=*x;
	*x=*y;
	*y=temp;
	printf("\nAfter swaping value a=%d b=%d ",*x,*y);
}
void main()
{
	int a=10, b=20;
	clrscr();
	printf("\nBefore swaping value a=%d b=%d: ",a,b);
	swap(&a, &b);
	printf("\nAfter swaping value a=%d b=%d ",a,b);
	getch();
}*/
#include<stdio.h>
#include<conio.h>

void swap(int x, int y)
{
	int temp;
	temp=x;
	x=y;
	y=temp;
	printf("\nAfter swaping value a=%d b=%d ",x,y);
}
void main()
{
	int a=10, b=20;
	clrscr();
	printf("\nBefore swaping value a=%d b=%d: ",a,b);
	swap(a, b);
	printf("\nAfter swaping value a=%d b=%d ",a,b);
	getch();
}








